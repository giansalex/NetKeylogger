Pasos:

- Desahibilitar el antivirus:
- Ejecutar el setup.exe
- A�adir la ruta del programa a la lista de exclusiones del antivirus.
   Activar ver archivos ocultos.
   Ruta del programa : C:\Users\[tu usuario aqui]\AppData\Local\Apps\2.0\0ME1XGEH.X49\A81156E4.269\keyl..tion_0400f5a861b092ce_0001.0000_08e60ed16a3b0e04\Keylogger.exe


--- Fecha Release: 01/02/2017